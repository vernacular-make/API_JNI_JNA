package com.test;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
/**
 * 2020-7-1 15:42
 */

/** Simple example of native library declaration and usage. */

public class HelloWorld {
	public interface CLibrary extends Library {
		  //(Platform.isWindows() ? "msvcrt" : "c") ;msvcrt:系统自带的动态链接库
          @SuppressWarnings("deprecation")
	    	CLibrary INSTANCE = (CLibrary)
          Native.loadLibrary((Platform.isWindows() ? "msvcrt" : "c"),CLibrary.class);
          void printf(String format, Object... args);
    }
	public static void main(String[] args) {
		 CLibrary.INSTANCE.printf("Hello, World/n");
		 //这个程序实际上是使用msvcrt.dll这个C运行时库中的printf函数打印出上面这些字符的。
         //for (int i=0;i < args.length;i++) { 
	     //CLibrary.INSTANCE.printf("Argument %d: %s/n", i, args[i]);}
     }
}	