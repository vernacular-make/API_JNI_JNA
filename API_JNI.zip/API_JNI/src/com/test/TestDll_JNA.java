package com.test;
import com.sun.jna.*;
public class TestDll_JNA {
	public interface TestDll extends Library {
		TestDll INSTANCE=(TestDll)Native.loadLibrary("TestJNA", TestDll.class);
		public void say(WString value);
	}
	
	//构造函数
	 public TestDll_JNA(){
         // TODO Auto-generated constructor stub
     }
	 
	 public static void main(String[] args) {
		 System.load("D:\\Documents\\Visual Studio 2010\\Projects\\TestJNA\\x64\\Release\\TestJNA.dll"); //绝对路径
		 System.out.print("I love you");
		 TestDll.INSTANCE.say(new WString("Hello World"));
	 }
}

	