#include "TestJNA.h"
#include "stdio.h"
#include <iostream>
#include <locale>
using namespace std;

void say(wchar_t* pValue){
	 //wide word to print chinese   L" "
	 locale loc("chs");
	 wcout.imbue(loc);
	 //std::wcout.imbue(std::locale("chs"));
	 //std::wcout<< L"�ϵ�˵��"<<pValue<<std::endl;
	 std::wcout<< L"�ϵ�˵��"<<endl;
     std:wcout<<pValue<<std::endl;
}

