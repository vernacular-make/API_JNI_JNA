#define MYLIBAPI  extern   "C"  __declspec(dllexport)
MYLIBAPI void say(wchar_t* pValue);

//#define extern "C"     
//void say(wchar_t* pValue);