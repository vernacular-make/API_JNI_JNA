#include "com_test_JNIDemo.h"
#include <iostream>
#include <stdio.h>
using namespace std;

JNIEXPORT void JNICALL Java_com_test_JNIDemo_testHello(JNIEnv *, jobject){
	std::cout<<"Are you ok"<<endl;
	printf("this is C++ print");
}
