#pragma once
class TestJNI
{
public:
	TestJNI(void);
	~TestJNI(void);
};

